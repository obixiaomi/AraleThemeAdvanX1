# DR. SLUMP – ARALE EDITION untuk ADVAN X1

Ini adalah **proyek sumber aplikasi Android**, bukan APK yang sudah dikompilasi.

## Fitur
- Pratinjau wallpaper Arale dan teman-teman di Penguin Village.
- Tombol memasang wallpaper layar utama.
- Tombol memasang wallpaper layar kunci (Android 7.0+).
- Tombol memasang wallpaper pada keduanya.
- Tidak meminta izin penyimpanan; wallpaper dibaca dari resource aplikasi.

## Batasan
Aplikasi ini hanya mengatur wallpaper. Launcher bawaan dido OS mungkin tidak mengizinkan aplikasi pihak ketiga mengganti ikon, widget, status bar, atau menu sistem secara otomatis. Karena itu bagian tersebut tidak dijanjikan berubah.

## Cara membangun APK
1. Buka folder proyek ini di Android Studio pada komputer.
2. Izinkan Android Studio menyinkronkan Gradle dan memasang Android SDK 35 jika diminta.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.
5. Pindahkan APK ke Advan X1, buka file tersebut, lalu izinkan pemasangan dari sumber itu jika Android memintanya.

Target: Android 14, minSdk 23, compileSdk 35.
