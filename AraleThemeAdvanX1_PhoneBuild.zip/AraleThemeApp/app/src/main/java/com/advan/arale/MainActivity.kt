package com.advan.arale

import android.app.Activity
import android.app.WallpaperManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 87, 200)
        window.navigationBarColor = android.graphics.Color.rgb(5, 43, 102)

        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 28, 28, 32)
            setBackgroundColor(android.graphics.Color.rgb(226, 243, 255))
        }
        scroll.addView(page)

        val heading = TextView(this).apply {
            text = "DR. SLUMP\nARALE EDITION"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(7, 66, 155))
            setPadding(8, 8, 8, 16)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        page.addView(heading)

        val subtitle = TextView(this).apply {
            text = "Tema wallpaper untuk ADVAN X1 • Android 14\nArale dan teman-teman dari Penguin Village"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.DKGRAY)
            setPadding(8, 0, 8, 18)
        }
        page.addView(subtitle)

        val preview = ImageView(this).apply {
            setImageResource(R.drawable.arale_wallpaper)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Wallpaper Arale dan teman-teman"
        }
        page.addView(preview, LinearLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.78f).toInt(),
            (resources.displayMetrics.heightPixels * 0.48f).toInt()
        ).apply { bottomMargin = 20 })

        addAction(page, "Pasang di layar utama") { setWallpaper(WallpaperManager.FLAG_SYSTEM) }
        addAction(page, "Pasang di layar kunci") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) setWallpaper(WallpaperManager.FLAG_LOCK)
            else toast("Layar kunci memerlukan Android 7.0 atau lebih baru")
        }
        addAction(page, "Pasang di keduanya") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) setWallpaper(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
            else setWallpaper(WallpaperManager.FLAG_SYSTEM)
        }

        val note = TextView(this).apply {
            text = "Catatan: aplikasi ini mengatur wallpaper. Ikon aplikasi, widget, status bar, dan menu sistem tidak berubah otomatis karena mengikuti dukungan launcher bawaan dido OS."
            textSize = 12f
            setTextColor(android.graphics.Color.DKGRAY)
            setPadding(8, 18, 8, 0)
        }
        page.addView(note)
        setContentView(scroll)
    }

    private fun addAction(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = 8
        })
    }

    private fun setWallpaper(flags: Int) {
        try {
            val manager = WallpaperManager.getInstance(this)
            resources.openRawResource(R.drawable.arale_wallpaper).use { stream ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) manager.setStream(stream, null, true, flags)
                else manager.setStream(stream)
            }
            toast("Wallpaper Arale berhasil diterapkan!")
        } catch (e: Exception) {
            toast("Gagal memasang wallpaper: ${e.localizedMessage ?: "coba lagi"}")
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
