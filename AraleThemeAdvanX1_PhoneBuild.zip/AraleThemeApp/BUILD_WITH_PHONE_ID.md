# Membuat APK hanya dengan HP (tanpa laptop)

Proyek ini disertai workflow GitHub Actions untuk membangun APK di komputer cloud GitHub.

1. Buat akun GitHub jika belum punya.
2. Di browser HP, buat repository baru di GitHub.
3. Unggah seluruh isi folder `AraleThemeApp` ke repository (termasuk folder tersembunyi `.github/workflows`).
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build Arale Theme APK**, lalu tekan **Run workflow**.
6. Tunggu sampai proses selesai dengan status hijau.
7. Buka hasil workflow, cari bagian **Artifacts**, lalu unduh `AraleThemeAdvanX1-debug-apk`.
8. Ekstrak ZIP artifact dan buka `app-debug.apk` di Advan X1. Jika diminta, izinkan instalasi dari sumber browser/file manager.

Catatan:
- Ini membangun APK debug untuk pengujian/pemasangan pribadi, bukan APK rilis bertanda tangan untuk Play Store.
- GitHub Actions memerlukan akun GitHub dan koneksi internet. Tidak perlu laptop, tetapi proses unggah folder dan menjalankan workflow dilakukan dari browser HP.
- Aplikasi saat ini memasang wallpaper layar utama/kunci. Aplikasi tidak mengubah seluruh ikon atau menu sistem.
